package com.example.school_for_teach

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
